﻿using System.ComponentModel.DataAnnotations.Schema;
using System.ComponentModel.DataAnnotations;
using SummitComBillingSystem.Models;

namespace SummitComBillingSystem.Entity
{
    public class ClientMapping:BaseClass
    {        
        public int ClientId { get; set; }        
        public string Name { get; set; }        
        public string Email { get; set; }

        public int ApplicationUserId { get; set; }

        //[ForeignKey("ApplicationUserId")]
        //public ApplicationUser ApplicationUser { get; set; }
    }
}
