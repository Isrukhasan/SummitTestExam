﻿namespace SummitComBillingSystem.Models;

/// <summary>
/// The base class
/// </summary>
public class BaseClass
{
    
    public Guid Id { get; set; }
    public int IsDeleted  { get; set; }

}
