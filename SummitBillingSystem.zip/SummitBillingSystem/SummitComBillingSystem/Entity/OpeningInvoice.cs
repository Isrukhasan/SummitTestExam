﻿namespace SummitComBillingSystem.Models;

/// <summary>
/// Opening invoice entity
/// </summary>
public class OpeningInvoice: BaseClass
{
    public DateTime BillingStartDate { get; set; }
    public int ClientId { get; set; }
    public DateTime BillingEndDate { get; set; }
    public  decimal CapacityQty  { get; set; }
    public decimal Rate { get; set; }
    public decimal CalculatedBillingAmount { get; set; }
}
