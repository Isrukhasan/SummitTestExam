﻿using Microsoft.AspNetCore.Mvc;

namespace SummitComBillingSystem.Controllers
{
    public class BillingConteroller : Controller
    {
        public IActionResult Index()
        {
            return View();
        }

        public IActionResult GenerateBilling()
        {
            return View();
        }

        public async Task<IActionResult> GenerateBilling(IFormCollection collection)
        {
            if (collection == null) {
                
            }

            //Call sp here

            // write on the table
        }
    }
}
