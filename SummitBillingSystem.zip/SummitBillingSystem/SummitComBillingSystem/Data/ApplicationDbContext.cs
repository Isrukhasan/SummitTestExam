﻿using Microsoft.AspNetCore.Identity.EntityFrameworkCore;
using Microsoft.EntityFrameworkCore;
using SummitComBillingSystem.Entity;
using SummitComBillingSystem.Models;

namespace SummitComBillingSystem.Data
{
    public class ApplicationDbContext : IdentityDbContext
    {
        public ApplicationDbContext(DbContextOptions<ApplicationDbContext> options)
            : base(options)
        {
        }
        public DbSet<OpeningInvoice> OpeningInvoice { get; set; }        
        public DbSet<ClientMapping> ClientMapping { get; set; }
    }
}
